﻿
export default function Test01()
{
}

Test01.prototype.Msg = function ()
{
    return " - 테스트 입니다!!";
};

